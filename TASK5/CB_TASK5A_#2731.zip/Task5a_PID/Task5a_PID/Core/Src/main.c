/* USER CODE BEGIN Header */

/********************************************************************************
 * @file           : main.c
 * @brief          : CropDrop Bot - Pick and Place with Line Following
 ******************************************************************************
 ******************************************************************************
 * @attention
 *
 * Copyright (c) 2025 STMicroelectronics.
 * All rights reserved.
 *
 * This software is licensed under terms that can be found in the LICENSE file
 * in the root directory of this software component.
 * If no LICENSE file comes with this software, it is provided AS-IS.
 *******************************************************************************

 */

/* USER CODE END Header */

/* Includes ------------------------------------------------------------------*/

#include "main.h"

/* Private includes ----------------------------------------------------------*/

/* USER CODE BEGIN Includes */

#include <stdio.h>
#include <string.h>
#include "Color.h"

/* USER CODE END Includes */

/* Private typedef -----------------------------------------------------------*/

/* USER CODE BEGIN PTD */

/* USER CODE END PTD */

/* Private define ------------------------------------------------------------*/

/* USER CODE BEGIN PD */

#define PWM_MAX 255

// Left Motor (L298N)
#define LM_IN1 TIM_CHANNEL_1   // PA0
#define LM_IN2 TIM_CHANNEL_2   // PA1

// Right Motor (L298N)
#define RM_IN1 TIM_CHANNEL_3   // PA2
#define RM_IN2 TIM_CHANNEL_4   // PA3
#define TURN_SPEED     110
#define STOP_TIME_MS   1000

/* USER CODE END PD */

/* Private macro -------------------------------------------------------------*/

/* USER CODE BEGIN PM */

/* USER CODE END PM */

/* Private variables ---------------------------------------------------------*/
ADC_HandleTypeDef hadc1;
DMA_HandleTypeDef hdma_adc1;
TIM_HandleTypeDef htim2;
TIM_HandleTypeDef htim3;
UART_HandleTypeDef huart2;

/* USER CODE BEGIN PV */

volatile uint16_t adcBuffer[5];
char uartBuf[100];       // UART print buffer

uint16_t irMin[5];
uint16_t irMax[5];
uint16_t irThreshold[5];

uint16_t sensorNorm[5];     // 0–1000 normalized
uint8_t sensorBinary[5];   // 1 = white, 0 = black
int8_t sensorWeight[5] = { -2, -1, 0, 1, 2 };

typedef enum {
	DIR_STRAIGHT = 0,
	DIR_LEFT,
	DIR_RIGHT
} Direction_t;

typedef enum {
	STATE_PID,
	STATE_PEEK_FORWARD,
	STATE_STOP_BEFORE_TURN,
	STATE_TURNING,
	ALL_BLACK_FORWARD,
	ALL_BLACK_CHECK,
	INVERSE_LINE,
	STATE_OBJECT_DETECTED,
	STATE_PICKING,
	STATE_FINAL_DROP
} RobotState_t;

RobotState_t robotState = STATE_PID;
Direction_t storedDirection = DIR_STRAIGHT;
uint32_t stateStartTime = 0;

typedef enum {
	LINE_WHITE_ON_BLACK = 0,   // white line, black surface
	LINE_BLACK_ON_WHITE = 1       // black line, white surface
} LineType_t;

LineType_t currentLineType = LINE_WHITE_ON_BLACK;

uint8_t onLine = 0;
float lineError = 0;
float Kp = 0.15f;
float Ki = 0.002f;
float Kd = 0.15f;
float pid_P = 0, pid_I = 0, pid_D = 0;
float previousError = 0;
float pidOutput = 0;

/* Base speed settings */
uint8_t currentspeed = 50;
uint8_t baseSpeed = 150;     // cruising speed
uint8_t maxSpeed = 200;     // safety limit

uint8_t Bval = 0;
uint8_t inSharpTurn = 0;
uint8_t bit_sensor;

/* Pick and Place variables */
uint8_t hasPackage = 0;
uint32_t colorRed = 0, colorGreen = 0, colorBlue = 0;

uint8_t blackZoneCounter = 0;
uint32_t blackDetectionStartTime = 0;
uint8_t countingActive = 0;
uint8_t zoneLock = 0;        // 1 = currently ignore junctions/stops
uint32_t lockStartTime = 0;  // Timer to prevent early reset after a turn
uint8_t turnConfirm = 0;     // To ensure we found a solid line, not a stray dot

/* ADDED: Printf support */
int _write(int file, char *ptr, int len)
{
	HAL_UART_Transmit(&huart2, (uint8_t*) ptr, len, HAL_MAX_DELAY);
	return len;
}

/* USER CODE END PV */

/* Private function prototypes -----------------------------------------------*/
void SystemClock_Config(void);
static void MX_GPIO_Init(void);
static void MX_DMA_Init(void);
static void MX_USART2_UART_Init(void);
static void MX_ADC1_Init(void);
static void MX_TIM2_Init(void);
static void MX_TIM3_Init(void);

/* USER CODE BEGIN PFP */
void Motor_180_Turn(void);
void Motor_Stop(void);
void Motor_Forward(uint8_t left_speed, uint8_t right_speed);
void Motor_Reverse(uint8_t left_speed, uint8_t right_speed);
void Motor_Turn_Left(uint8_t left_speed, uint8_t right_speed);
void Motor_Turn_Right(uint8_t left_speed, uint8_t right_speed);
void Calibrate_IR_Sensors(void);
void Read_Line_Sensors(void);
float Compute_Line_Error(void);
void Line_PID_Control(void);
void Print_Sensor_Binary(void);
void side_calibration(void);
void Handle_Object_Detection(void);  // ⭐ ADDED
void Handle_Drop_Point(void);        // ⭐ ADDED

/* USER CODE END PFP */

/* Private user code ---------------------------------------------------------*/

/* USER CODE BEGIN 0 */

/* USER CODE END 0 */

/**
 * @brief  The application entry point.
 * @retval int
 */

int main(void)
{
	/* USER CODE BEGIN 1 */

	/* USER CODE END 1 */

	/* MCU Configuration--------------------------------------------------------*/

	/* Reset of all peripherals, Initializes the Flash interface and the Systick. */
	HAL_Init();

	/* USER CODE BEGIN Init */

	/* USER CODE END Init */

	/* Configure the system clock */
	SystemClock_Config();

	/* USER CODE BEGIN SysInit */

	/* USER CODE END SysInit */

	/* Initialize all configured peripherals */
	MX_GPIO_Init();
	MX_DMA_Init();
	MX_USART2_UART_Init();
	MX_ADC1_Init();
	MX_TIM2_Init();
	MX_TIM3_Init();

	/* USER CODE BEGIN 2 */
	HAL_ADC_Start_DMA(&hadc1, (uint32_t*) adcBuffer, 5);
	HAL_TIM_PWM_Start(&htim2, TIM_CHANNEL_1);
	HAL_TIM_PWM_Start(&htim2, TIM_CHANNEL_2);
	HAL_TIM_PWM_Start(&htim2, TIM_CHANNEL_3);
	HAL_TIM_PWM_Start(&htim2, TIM_CHANNEL_4);

	// Initialize Color Sensor
	Color_Init(&htim3);
	HAL_Delay(500);          // wait before calibration

	Calibrate_IR_Sensors();

	printf("=== CropDrop Bot Ready ===\r\n");

	/* USER CODE END 2 */

	/* Infinite loop */

	/* USER CODE BEGIN WHILE */

	while (1)
	{
		/* USER CODE END WHILE */

		/* USER CODE BEGIN 3 */

		Read_Line_Sensors();
		lineError = Compute_Line_Error();

		if (currentspeed < baseSpeed) {
			currentspeed++;
		}

		/* ========== STATE:  PID LINE FOLLOWING ========== */
		if (robotState == STATE_PID)
		{
			// 1. Check for object detection at pickup point
			    uint8_t ir_state = HAL_GPIO_ReadPin(Box_detect_GPIO_Port, Box_detect_Pin);

			    if (ir_state == 0 && !hasPackage)
			    {
			        robotState = STATE_OBJECT_DETECTED;
			        Motor_Stop();
			        HAL_Delay(200);
			        continue;
			    }


//			    if (currentLineType == LINE_BLACK_ON_WHITE && hasPackage)
//			    {
//			        // --- 1. DETECTION PHASE (Only if not locked) ---
//			        if (zoneLock == 0)
//			        {
//			            // PRIORITY: Right Turn (01111)
//			            // Check if right-most bit is 1 AND center bit is 1
//			            if ((bit_sensor & 0b00001) && (bit_sensor & 0b00100))
//			            {
//			                printf("Confirmed Junction: Turning Right\r\n");
//			                zoneLock = 1;
//			                lockStartTime = HAL_GetTick();
//			                stateStartTime = HAL_GetTick(); // Mark when we triggered the lock
//
//			                Motor_Forward(baseSpeed, baseSpeed);
//			                HAL_Delay(370);
//
//			                storedDirection = DIR_RIGHT;
//			                robotState = STATE_TURNING;
//			                continue;
//			            }
//
//			            // PRIORITY: Drop Point C (01110)
//			            // Added a stable counter to prevent stopping "in between" the line
//			            static uint8_t stopDebounce = 0;
//			            if (bit_sensor == 0b01110)
//			            {
//			                stopDebounce++;
//			                if(stopDebounce > 15) // Must see stop pattern for 15 cycles
//			                {
//			                    printf("Confirmed Point C: Stopping\r\n");
//			                    robotState = STATE_FINAL_DROP;
//			                    stopDebounce = 0;
//			                    continue;
//			                }
//			            }
//			            else {
//			                stopDebounce = 0;
//			            }
//			        }
//			    if (zoneLock == 1)
//			    			        {
//			    			            if ((bit_sensor == 0b00100) && (HAL_GetTick() - stateStartTime > 800))
//			    			            {
//			    			                printf("ZoneLock Reset: Ready for next junction.\r\n");
//			    			                zoneLock = 0;
//			    			            }
//			    			        }
//			   }


			    if (currentLineType == LINE_BLACK_ON_WHITE && hasPackage)
			    {
			        if (zoneLock == 0)
			        {
			            /* --- 1. DROP POINT C (Pattern: 01110) --- */
			            // Explicitly check that the middle 3 are ON and the far right is OFF
			            if (((bit_sensor & 0b01110) == 0b01110) && !(bit_sensor & 0b00001))
			            {
			                static uint8_t stopDebounce = 0;
			                stopDebounce++;
			                if(stopDebounce >= 3)
			                {
			                    Motor_Reverse(baseSpeed, baseSpeed);
			                    HAL_Delay(60); // Stronger brake
			                    Motor_Stop();

			                    printf("Confirmed Point C: Stopping\r\n");
			                    robotState = STATE_FINAL_DROP;
			                    stopDebounce = 0;
			                    continue;
			                }
			            }
			            else {
			                // Priority 2: JUNCTION RIGHT (Pattern: 01111 or 00111)
			                // Check that the middle and far right are both ON
			                if ((bit_sensor & 0b00100) && (bit_sensor & 0b00001))
			                {
			                    printf("Confirmed Junction: Turning Right\r\n");
			                    zoneLock = 1;
			                    stateStartTime = HAL_GetTick();

			                    Motor_Forward(baseSpeed, baseSpeed);
			                    HAL_Delay(370);

			                    storedDirection = DIR_RIGHT;
			                    robotState = STATE_TURNING;
			                    continue;
			                }
			            }
			        }

			        /* --- 3. SMART RESET PHASE --- */
			        if (zoneLock == 1)
			        {
			            if ((bit_sensor == 0b00100) && (HAL_GetTick() - stateStartTime > 800))
			            {
			                printf("ZoneLock Reset\r\n");
			                zoneLock = 0;
			            }
			        }
			    }




			    // 2. Logic for Counting All-Black Zones (Drop Zones/Markers)
			    // Assuming 0b00000 is the sensor reading for all black
			    // 2. Handle Black Zone Markers (Node 1 = Turn Right, Node 2 = Drop)
//			        if (bit_sensor == 0b00000)
//			        {
//			            uint32_t pressTime = HAL_GetTick();
//			            while(bit_sensor == 0b00000 && (HAL_GetTick() - pressTime < 150)) {
//			                Read_Line_Sensors();
//			                Compute_Line_Error();
//			            }
//
//			            if (HAL_GetTick() - pressTime >= 150 && zoneLock == 0)
//			            {
//			                blackZoneCounter++;
//			                zoneLock = 1;
//			                printf("Node Detected: %d\r\n", blackZoneCounter);
//
//			                if (hasPackage)
//			                {
//			                    if (blackZoneCounter == 1)
//			                    {
//			                        printf("Node 1: Turning Right toward Drop Zone...\r\n");
//			                        // Move forward slightly to center the pivot point on the junction
//			                        Motor_Forward(baseSpeed, baseSpeed);
//			                        HAL_Delay(250);
//
//			                        storedDirection = DIR_RIGHT;
//			                        robotState = STATE_TURNING;
//			                        stateStartTime = HAL_GetTick();
//			                        continue;
//			                    }
//			                    else if (blackZoneCounter == 2)
//			                    {
//			                        printf("Node 2: Target Reached. Dropping...\r\n");
//			                        robotState = STATE_FINAL_DROP;
//			                        stateStartTime = HAL_GetTick();
//			                        continue;
//			                    }
//			                }
//			            }
//			        }
//			        else {
//			            zoneLock = 0;
//			        }

			        // Maintain magnet hold during PID
			        if (hasPackage) {
			            HAL_GPIO_WritePin(Electromagnet_GPIO_Port, Electromagnet_Pin, GPIO_PIN_SET);
			        }

			// 3. SEAMLESS INVERSE TOGGLE (Approach 1)
			// We check for specific transition patterns (e.g., 0b11011 or 0b10111)
			if (bit_sensor == 0b11011 || bit_sensor == 0b10001
					|| bit_sensor == 0b11101 || bit_sensor == 0b10111)
					{
				// Toggle current mode
				if (currentLineType == LINE_WHITE_ON_BLACK) {
					currentLineType = LINE_BLACK_ON_WHITE;
					printf(">>> SWAP: Black Line Mode <<<\r\n");
				} else {
					currentLineType = LINE_WHITE_ON_BLACK;
					printf(">>> SWAP: White Line Mode <<<\r\n");
				}

				// Crucial: Move past the marker so we don't trigger the toggle again immediately
				Motor_Forward(baseSpeed, baseSpeed);
				HAL_Delay(150);

				pid_I = 0;
				previousError = 0;

				continue;
			}
			// Sharp left turn detection
			if (bit_sensor == 0b11100 || bit_sensor == 0b11000
					|| bit_sensor == 0b10000)
			{
				storedDirection = DIR_LEFT;
				robotState = STATE_PEEK_FORWARD;
				stateStartTime = HAL_GetTick();

				continue;

			}
			// Sharp right turn detection
			if (bit_sensor == 0b00111 || bit_sensor == 0b00011
					|| bit_sensor == 0b00001)
			{
				storedDirection = DIR_RIGHT;
				robotState = STATE_PEEK_FORWARD;
				stateStartTime = HAL_GetTick();

				continue;

			}

			// Inverse line (stop condition)

//	        if(bit_sensor == 0b11011 || bit_sensor == 0b10001 ||

//	           bit_sensor == 0b11101 || bit_sensor == 0b10111)

//	        {

//	        	robotState = INVERSE_LINE;

//	        	continue;

//	        }

			// Normal PID control
			Line_PID_Control();

		}

		/* ⭐ ADDED: STATE: OBJECT DETECTED */
		else if (robotState == STATE_OBJECT_DETECTED)
		{
			Handle_Object_Detection();
			continue;
		}

		/* ⭐ ADDED: STATE: PICKING */
		else if (robotState == STATE_PICKING)
		{
			if (HAL_GetTick() - stateStartTime > 1000)  // Wait 1 sec for pickup
			{
				printf("Package picked!\r\n");
				hasPackage = 1;
				robotState = STATE_PID;
				pid_I = 0;
				previousError = 0;
			}
			continue;
		}
		/* ========== STATE: FINAL DROP ========== */
		else if (robotState == STATE_FINAL_DROP)
		{
		    Motor_Stop();
		    printf("Dropping box at Zone C...\r\n");

		    // Release Magnet
		    HAL_GPIO_WritePin(Electromagnet_GPIO_Port, Electromagnet_Pin, GPIO_PIN_RESET);
		    HAL_Delay(1000);

		    printf("Mission Complete! Blinking White LED...\r\n");

		    while (1) // Infinite blink loop
		    {
		        // White = Red + Green + Blue
		        HAL_GPIO_WritePin(GPIOC, RED_Pin | GREEN_Pin | BLUE_Pin, GPIO_PIN_SET);
		        HAL_Delay(500);
		        HAL_GPIO_WritePin(GPIOC, RED_Pin | GREEN_Pin | BLUE_Pin, GPIO_PIN_RESET);
		        HAL_Delay(500);
		    }
		}

		/* ========== STATE: INVERSE LINE (STOP) ========== */

//	    else if(robotState == INVERSE_LINE)
//	    {
//	    	Motor_Stop();
//	    	HAL_GPIO_WritePin(Electromagnet_GPIO_Port, Electromagnet_Pin, GPIO_PIN_RESET);  // ⭐ ADDED
//	    	printf("End of track!\r\n");
//	    	continue;
//	    }

		/* ========== STATE: PEEK FORWARD (Dotted Line Handler) ========== */
//		else if (robotState == STATE_PEEK_FORWARD)
//		{
//		    // Move forward slightly faster to bridge the gap
//		    Motor_Forward(baseSpeed - 50, baseSpeed - 50);
//
//		    // If it's a dotted line, we might find the line again while peeking!
//		    if (sensorBinary[2] == 1) // Center sensor found a dot
//		    {
//		        robotState = STATE_PID; // Resume PID immediately
//		        continue;
//		    }
//
//		    // REDUCE THIS: If it was 350ms, try 200ms or 250ms.
//		    // It should be just long enough to clear the "gap" but not the whole line.
//		    if (HAL_GetTick() - stateStartTime > 200)
//		    {
//		        // If we still haven't found a line, proceed to the turn
//		        robotState = STATE_TURNING;
//		        stateStartTime = HAL_GetTick();
//		    }
//		    continue;
//		}


		/* ========== STATE: TURNING (Dynamic Speed & Persistence) ========== */
//		else if (robotState == STATE_TURNING)
//		{
//		    // Determine speed based on line type
//		    uint8_t activeTurnSpeed;
//
//		    if (currentLineType == LINE_BLACK_ON_WHITE)
//		    {
//		        activeTurnSpeed = TURN_SPEED;      // Use your dedicated Turn Speed for Inverse
//		    }
//		    else
//		    {
//		        activeTurnSpeed = baseSpeed - 55;  // Use your calculated speed for Normal
//		    }
//
//		    // Apply the determined speed to motors
//		    if (storedDirection == DIR_LEFT)
//		        Motor_Turn_Left(activeTurnSpeed, activeTurnSpeed);
//		    else
//		        Motor_Turn_Right(activeTurnSpeed, activeTurnSpeed);
//
//		    // 2. Line Detection Logic
//		        if (currentLineType == LINE_BLACK_ON_WHITE)
//		        {
//		            /* --- PERSISTENCE LOGIC (For Inverse/Dotted Line) --- */
//		            static uint8_t turnConfirm = 0;
//		            if (sensorBinary[2] == 1)
//		            {
//		                turnConfirm++;
//		                if (turnConfirm >= 5)
//		                {
//		                    Motor_Stop();
//		                    pid_I = 0;
//		                    previousError = 0;
//		                    storedDirection = DIR_STRAIGHT;
//		                    robotState = STATE_PID;
//		                    turnConfirm = 0;
//		                }
//		            }
//		            else {
//		                turnConfirm = 0;
//		            }
//		        }
//		        else
//		        {
//		            /* --- SIMPLE LOGIC (For Normal White Line) --- */
//		            if (sensorBinary[2] == 1)
//		            {
//		                Motor_Stop();
//		                pid_I = 0;
//		                previousError = 0;
//		                storedDirection = DIR_STRAIGHT;
//		                robotState = STATE_PID;
//		            }
//		        }
//		    continue;
//		}

		else if (robotState == STATE_PEEK_FORWARD)
		{
					Motor_Forward(100, 100);

					if (HAL_GetTick() - stateStartTime > 170)
					{
						robotState = STATE_TURNING;
						stateStartTime = HAL_GetTick();
					}
					continue;
		}

//		/* ========== STATE: TURNING (Dotted Line Persistence) ========== */
		else if (robotState == STATE_TURNING)
		{
		    if (storedDirection == DIR_LEFT)
		        Motor_Turn_Left(baseSpeed + 25, baseSpeed + 25);
		    else
		        Motor_Turn_Right(baseSpeed + 25, baseSpeed + 25);

		    // Only exit turning if the center sensor is solidly on a line
		    // We add a small debounce check here so it doesn't catch a "stray dot"
		    static uint8_t turnConfirm = 0;
		    if (sensorBinary[2] == 1)
		    {
		        turnConfirm++;
		        if(turnConfirm >= 3) {
		            Motor_Stop();
		            pid_I = 0;
		            previousError = 0;
		            storedDirection = DIR_STRAIGHT;
		            robotState = STATE_PID;
		            turnConfirm = 0;
		        }
		    }
		    else {
		        turnConfirm = 0;
		    }
		    continue;
		}

		/* ========== STATE:  PEEK FORWARD ========== */
//		else if (robotState == STATE_PEEK_FORWARD)
//		{
//			Motor_Forward(100, 100);
//
//			if (HAL_GetTick() - stateStartTime > 170)
//			{
//				robotState = STATE_TURNING;
//				stateStartTime = HAL_GetTick();
//			}
//			continue;
//		}
//
//		/* ========== STATE: TURNING ========== */
//		else if (robotState == STATE_TURNING)
//		{
//			if (storedDirection == DIR_LEFT)
//				Motor_Turn_Left(baseSpeed - 13, baseSpeed - 13);
//			else
//				Motor_Turn_Right(baseSpeed - 13, baseSpeed - 13);
//
//			if (sensorBinary[2])   // center sensor found line
//			{
//				Motor_Stop();
//				pid_I = 0;
//				previousError = 0;
//				storedDirection = DIR_STRAIGHT;
//				robotState = STATE_PID;
//			}
//			continue;
//		}


	}
	/* USER CODE END 3 */
}

/**
 * @brief System Clock Configuration
 * @retval None
 */

void SystemClock_Config(void)
{
	RCC_OscInitTypeDef RCC_OscInitStruct = { 0 };
	RCC_ClkInitTypeDef RCC_ClkInitStruct = { 0 };
	RCC_PeriphCLKInitTypeDef PeriphClkInit = { 0 };

	/** Initializes the RCC Oscillators according to the specified parameters
	 * in the RCC_OscInitTypeDef structure.
	 */
	RCC_OscInitStruct.OscillatorType = RCC_OSCILLATORTYPE_HSE;
	RCC_OscInitStruct.HSEState = RCC_HSE_BYPASS;
	RCC_OscInitStruct.HSEPredivValue = RCC_HSE_PREDIV_DIV1;
	RCC_OscInitStruct.HSIState = RCC_HSI_ON;
	RCC_OscInitStruct.PLL.PLLState = RCC_PLL_ON;
	RCC_OscInitStruct.PLL.PLLSource = RCC_PLLSOURCE_HSE;
	RCC_OscInitStruct.PLL.PLLMUL = RCC_PLL_MUL9;

	if (HAL_RCC_OscConfig(&RCC_OscInitStruct) != HAL_OK)
	{
		Error_Handler();
	}

	/** Initializes the CPU, AHB and APB buses clocks
	 */
	RCC_ClkInitStruct.ClockType = RCC_CLOCKTYPE_HCLK | RCC_CLOCKTYPE_SYSCLK
	| RCC_CLOCKTYPE_PCLK1 | RCC_CLOCKTYPE_PCLK2;
	RCC_ClkInitStruct.SYSCLKSource = RCC_SYSCLKSOURCE_PLLCLK;
	RCC_ClkInitStruct.AHBCLKDivider = RCC_SYSCLK_DIV1;
	RCC_ClkInitStruct.APB1CLKDivider = RCC_HCLK_DIV2;
	RCC_ClkInitStruct.APB2CLKDivider = RCC_HCLK_DIV1;

	if (HAL_RCC_ClockConfig(&RCC_ClkInitStruct, FLASH_LATENCY_2) != HAL_OK)
	{
		Error_Handler();
	}

	PeriphClkInit.PeriphClockSelection = RCC_PERIPHCLK_ADC;
	PeriphClkInit.AdcClockSelection = RCC_ADCPCLK2_DIV6;

	if (HAL_RCCEx_PeriphCLKConfig(&PeriphClkInit) != HAL_OK)
	{
		Error_Handler();
	}
}

/**
 * @brief ADC1 Initialization Function
 * @param None
 * @retval None
 */

static void MX_ADC1_Init(void)
{
	/* USER CODE BEGIN ADC1_Init 0 */
	/* USER CODE END ADC1_Init 0 */
	ADC_ChannelConfTypeDef sConfig = { 0 };

	/* USER CODE BEGIN ADC1_Init 1 */
	/* USER CODE END ADC1_Init 1 */

	/** Common config
	 */
	hadc1.Instance = ADC1;
	hadc1.Init.ScanConvMode = ADC_SCAN_ENABLE;
	hadc1.Init.ContinuousConvMode = ENABLE;
	hadc1.Init.DiscontinuousConvMode = DISABLE;
	hadc1.Init.ExternalTrigConv = ADC_SOFTWARE_START;
	hadc1.Init.DataAlign = ADC_DATAALIGN_RIGHT;
	hadc1.Init.NbrOfConversion = 5;

	if (HAL_ADC_Init(&hadc1) != HAL_OK)
	{
		Error_Handler();
	}

	/** Configure Regular Channel
	 */
	sConfig.Channel = ADC_CHANNEL_10;
	sConfig.Rank = ADC_REGULAR_RANK_1;
	sConfig.SamplingTime = ADC_SAMPLETIME_55CYCLES_5;

	if (HAL_ADC_ConfigChannel(&hadc1, &sConfig) != HAL_OK)
	{
		Error_Handler();
	}

	/** Configure Regular Channel
	 */
	sConfig.Channel = ADC_CHANNEL_11;
	sConfig.Rank = ADC_REGULAR_RANK_2;

	if (HAL_ADC_ConfigChannel(&hadc1, &sConfig) != HAL_OK)
	{
		Error_Handler();
	}

	/** Configure Regular Channel
	 */
	sConfig.Channel = ADC_CHANNEL_12;
	sConfig.Rank = ADC_REGULAR_RANK_3;

	if (HAL_ADC_ConfigChannel(&hadc1, &sConfig) != HAL_OK)
	{
		Error_Handler();
	}

	/** Configure Regular Channel
	 */
	sConfig.Channel = ADC_CHANNEL_8;
	sConfig.Rank = ADC_REGULAR_RANK_4;

	if (HAL_ADC_ConfigChannel(&hadc1, &sConfig) != HAL_OK)
	{
		Error_Handler();
	}

	/** Configure Regular Channel
	 */
	sConfig.Channel = ADC_CHANNEL_9;
	sConfig.Rank = ADC_REGULAR_RANK_5;

	if (HAL_ADC_ConfigChannel(&hadc1, &sConfig) != HAL_OK)
	{
		Error_Handler();
	}

	/* USER CODE BEGIN ADC1_Init 2 */
	/* USER CODE END ADC1_Init 2 */
}

/**
 * @brief TIM2 Initialization Function
 * @param None
 * @retval None
 */

static void MX_TIM2_Init(void)
{
	/* USER CODE BEGIN TIM2_Init 0 */
	/* USER CODE END TIM2_Init 0 */

	TIM_MasterConfigTypeDef sMasterConfig = { 0 };
	TIM_OC_InitTypeDef sConfigOC = { 0 };

	/* USER CODE BEGIN TIM2_Init 1 */
	/* USER CODE END TIM2_Init 1 */

	htim2.Instance = TIM2;
	htim2.Init.Prescaler = 72 - 1;
	htim2.Init.CounterMode = TIM_COUNTERMODE_UP;
	htim2.Init.Period = 255;
	htim2.Init.ClockDivision = TIM_CLOCKDIVISION_DIV1;
	htim2.Init.AutoReloadPreload = TIM_AUTORELOAD_PRELOAD_DISABLE;

	if (HAL_TIM_PWM_Init(&htim2) != HAL_OK)
	{
		Error_Handler();
	}

	sMasterConfig.MasterOutputTrigger = TIM_TRGO_RESET;
	sMasterConfig.MasterSlaveMode = TIM_MASTERSLAVEMODE_DISABLE;

	if (HAL_TIMEx_MasterConfigSynchronization(&htim2, &sMasterConfig) != HAL_OK)
	{
		Error_Handler();
	}

	sConfigOC.OCMode = TIM_OCMODE_PWM1;
	sConfigOC.Pulse = 0;
	sConfigOC.OCPolarity = TIM_OCPOLARITY_HIGH;
	sConfigOC.OCFastMode = TIM_OCFAST_DISABLE;

	if (HAL_TIM_PWM_ConfigChannel(&htim2, &sConfigOC, TIM_CHANNEL_1) != HAL_OK)
	{
		Error_Handler();
	}

	if (HAL_TIM_PWM_ConfigChannel(&htim2, &sConfigOC, TIM_CHANNEL_2) != HAL_OK)
	{
		Error_Handler();
	}

	if (HAL_TIM_PWM_ConfigChannel(&htim2, &sConfigOC, TIM_CHANNEL_3) != HAL_OK)
	{
		Error_Handler();
	}

	if (HAL_TIM_PWM_ConfigChannel(&htim2, &sConfigOC, TIM_CHANNEL_4) != HAL_OK)
	{
		Error_Handler();
	}

	/* USER CODE BEGIN TIM2_Init 2 */
	/* USER CODE END TIM2_Init 2 */
	HAL_TIM_MspPostInit(&htim2);
}

/**
 * @brief TIM3 Initialization Function
 * @param None
 * @retval None
 */

static void MX_TIM3_Init(void)
{
	/* USER CODE BEGIN TIM3_Init 0 */
	/* USER CODE END TIM3_Init 0 */

	TIM_MasterConfigTypeDef sMasterConfig = { 0 };
	TIM_IC_InitTypeDef sConfigIC = { 0 };

	/* USER CODE BEGIN TIM3_Init 1 */
	/* USER CODE END TIM3_Init 1 */

	htim3.Instance = TIM3;
	htim3.Init.Prescaler = 71;
	htim3.Init.CounterMode = TIM_COUNTERMODE_UP;
	htim3.Init.Period = 65535;
	htim3.Init.ClockDivision = TIM_CLOCKDIVISION_DIV1;
	htim3.Init.AutoReloadPreload = TIM_AUTORELOAD_PRELOAD_DISABLE;

	if (HAL_TIM_IC_Init(&htim3) != HAL_OK)
	{
		Error_Handler();
	}

	sMasterConfig.MasterOutputTrigger = TIM_TRGO_RESET;
	sMasterConfig.MasterSlaveMode = TIM_MASTERSLAVEMODE_DISABLE;

	if (HAL_TIMEx_MasterConfigSynchronization(&htim3, &sMasterConfig) != HAL_OK)
	{
		Error_Handler();
	}

	sConfigIC.ICPolarity = TIM_INPUTCHANNELPOLARITY_RISING;
	sConfigIC.ICSelection = TIM_ICSELECTION_DIRECTTI;
	sConfigIC.ICPrescaler = TIM_ICPSC_DIV1;
	sConfigIC.ICFilter = 0;

	if (HAL_TIM_IC_ConfigChannel(&htim3, &sConfigIC, TIM_CHANNEL_1) != HAL_OK)
	{
		Error_Handler();
	}

	/* USER CODE BEGIN TIM3_Init 2 */
	/* USER CODE END TIM3_Init 2 */
}

/**
 * @brief USART2 Initialization Function
 * @param None
 * @retval None
 */

static void MX_USART2_UART_Init(void)
{
	/* USER CODE BEGIN USART2_Init 0 */
	/* USER CODE END USART2_Init 0 */
	/* USER CODE BEGIN USART2_Init 1 */
	/* USER CODE END USART2_Init 1 */
	huart2.Instance = USART2;
	huart2.Init.BaudRate = 115200;
	huart2.Init.WordLength = UART_WORDLENGTH_8B;
	huart2.Init.StopBits = UART_STOPBITS_1;
	huart2.Init.Parity = UART_PARITY_NONE;
	huart2.Init.Mode = UART_MODE_TX_RX;
	huart2.Init.HwFlowCtl = UART_HWCONTROL_NONE;
	huart2.Init.OverSampling = UART_OVERSAMPLING_16;

	if (HAL_UART_Init(&huart2) != HAL_OK)
	{
		Error_Handler();
	}

	/* USER CODE BEGIN USART2_Init 2 */
	/* USER CODE END USART2_Init 2 */
}

/**
 * Enable DMA controller clock
 */

static void MX_DMA_Init(void)
{
	/* DMA controller clock enable */
	__HAL_RCC_DMA1_CLK_ENABLE();

	/* DMA interrupt init */
	/* DMA1_Channel1_IRQn interrupt configuration */
	HAL_NVIC_SetPriority(DMA1_Channel1_IRQn, 0, 0);
	HAL_NVIC_EnableIRQ(DMA1_Channel1_IRQn);
}

/**
 * @brief GPIO Initialization Function
 * @param None
 * @retval None
 */

static void MX_GPIO_Init(void)

{
	GPIO_InitTypeDef GPIO_InitStruct = { 0 };
	/* USER CODE BEGIN MX_GPIO_Init_1 */
	/* USER CODE END MX_GPIO_Init_1 */

	/* GPIO Ports Clock Enable */
	__HAL_RCC_GPIOC_CLK_ENABLE();
	__HAL_RCC_GPIOD_CLK_ENABLE();
	__HAL_RCC_GPIOA_CLK_ENABLE();
	__HAL_RCC_GPIOB_CLK_ENABLE();

	/*Configure GPIO pin Output Level */
	HAL_GPIO_WritePin(GPIOA, Electromagnet_Pin | LD2_Pin, GPIO_PIN_RESET);
	/*Configure GPIO pin Output Level */
	HAL_GPIO_WritePin(GPIOB, S0_Pin | S1_Pin | S2_Pin | S3_Pin, GPIO_PIN_RESET);
	/*Configure GPIO pin Output Level */
	HAL_GPIO_WritePin(GPIOC, RED_Pin | GREEN_Pin | BLUE_Pin, GPIO_PIN_RESET);

	/*Configure GPIO pin : PUSH_BUTTON_Pin */
	GPIO_InitStruct.Pin = PUSH_BUTTON_Pin;
	GPIO_InitStruct.Mode = GPIO_MODE_INPUT;
	GPIO_InitStruct.Pull = GPIO_PULLUP;
	HAL_GPIO_Init(PUSH_BUTTON_GPIO_Port, &GPIO_InitStruct);

	/*Configure GPIO pins : Electromagnet_Pin LD2_Pin */
	GPIO_InitStruct.Pin = Electromagnet_Pin | LD2_Pin;
	GPIO_InitStruct.Mode = GPIO_MODE_OUTPUT_PP;
	GPIO_InitStruct.Pull = GPIO_NOPULL;
	GPIO_InitStruct.Speed = GPIO_SPEED_FREQ_LOW;
	HAL_GPIO_Init(GPIOA, &GPIO_InitStruct);

	/*Configure GPIO pins : S0_Pin S1_Pin S2_Pin S3_Pin */
	GPIO_InitStruct.Pin = S0_Pin | S1_Pin | S2_Pin | S3_Pin;
	GPIO_InitStruct.Mode = GPIO_MODE_OUTPUT_PP;
	GPIO_InitStruct.Pull = GPIO_NOPULL;
	GPIO_InitStruct.Speed = GPIO_SPEED_FREQ_LOW;
	HAL_GPIO_Init(GPIOB, &GPIO_InitStruct);

	/*Configure GPIO pins : RED_Pin GREEN_Pin BLUE_Pin */
	GPIO_InitStruct.Pin = RED_Pin | GREEN_Pin | BLUE_Pin;
	GPIO_InitStruct.Mode = GPIO_MODE_OUTPUT_PP;
	GPIO_InitStruct.Pull = GPIO_NOPULL;
	GPIO_InitStruct.Speed = GPIO_SPEED_FREQ_LOW;
	HAL_GPIO_Init(GPIOC, &GPIO_InitStruct);

	/*Configure GPIO pin : Box_detect_Pin */
	GPIO_InitStruct.Pin = Box_detect_Pin;
	GPIO_InitStruct.Mode = GPIO_MODE_INPUT;
	GPIO_InitStruct.Pull = GPIO_NOPULL;
	HAL_GPIO_Init(Box_detect_GPIO_Port, &GPIO_InitStruct);

	/* USER CODE BEGIN MX_GPIO_Init_2 */
	/* USER CODE END MX_GPIO_Init_2 */
}

/* USER CODE BEGIN 4 */

// ========== MOTOR CONTROL FUNCTIONS (UNCHANGED FROM CODE 1) =========
void Motor_180_Turn(void) {
    printf("180 Turn: Clearing start line...\r\n");

    // 1. Force turn to clear the current line (Blind phase)
    // Use a slightly lower, consistent speed for better control
    Motor_Turn_Right(TURN_SPEED, TURN_SPEED);
    HAL_Delay(1350);

    printf("180 Turn: Searching for line...\r\n");

    // 2. Search phase
    while (1) {
        // Force the rotation
        Motor_Turn_Right(TURN_SPEED, TURN_SPEED);

        // Update sensors
        Read_Line_Sensors();

        // Stop ONLY when the center sensor (sensorBinary[2]) finds the white line
        if (sensorBinary[2] == 1) {
            Motor_Stop();
            HAL_Delay(200); // Let physics settle
            printf("Line Found! Resuming PID.\r\n");
            break;
        }
    }
}

void Motor_Stop(void)
{
	__HAL_TIM_SET_COMPARE(&htim2, LM_IN1, 0);
	__HAL_TIM_SET_COMPARE(&htim2, LM_IN2, 0);
	__HAL_TIM_SET_COMPARE(&htim2, RM_IN1, 0);
	__HAL_TIM_SET_COMPARE(&htim2, RM_IN2, 0);
}

void Motor_Forward(uint8_t left_speed, uint8_t right_speed)
{
	__HAL_TIM_SET_COMPARE(&htim2, LM_IN1, left_speed);
	__HAL_TIM_SET_COMPARE(&htim2, LM_IN2, 0);
	__HAL_TIM_SET_COMPARE(&htim2, RM_IN1, right_speed);
	__HAL_TIM_SET_COMPARE(&htim2, RM_IN2, 0);
}

void Motor_Reverse(uint8_t left_speed, uint8_t right_speed)
{
	__HAL_TIM_SET_COMPARE(&htim2, LM_IN1, 0);
	__HAL_TIM_SET_COMPARE(&htim2, LM_IN2, left_speed);
	__HAL_TIM_SET_COMPARE(&htim2, RM_IN1, 0);
	__HAL_TIM_SET_COMPARE(&htim2, RM_IN2, right_speed);
}

void Motor_Turn_Left(uint8_t left_speed, uint8_t right_speed)
{
	__HAL_TIM_SET_COMPARE(&htim2, LM_IN1, 0);
	__HAL_TIM_SET_COMPARE(&htim2, LM_IN2, left_speed);
	__HAL_TIM_SET_COMPARE(&htim2, RM_IN1, right_speed);
	__HAL_TIM_SET_COMPARE(&htim2, RM_IN2, 0);
}

void Motor_Turn_Right(uint8_t left_speed, uint8_t right_speed)
{
	__HAL_TIM_SET_COMPARE(&htim2, LM_IN1, left_speed);
	__HAL_TIM_SET_COMPARE(&htim2, LM_IN2, 0);
	__HAL_TIM_SET_COMPARE(&htim2, RM_IN1, 0);
	__HAL_TIM_SET_COMPARE(&htim2, RM_IN2, right_speed);
}

// ========== IR SENSOR FUNCTIONS (UNCHANGED FROM CODE 1) ==========

void Calibrate_IR_Sensors(void)
{
	for (int i = 0; i < 5; i++)
	{
		irMin[i] = adcBuffer[i];
		irMax[i] = adcBuffer[i];
	}

	uint32_t startTime = HAL_GetTick();

	while (HAL_GetTick() - startTime < 4000)
	{
		Motor_Turn_Left(100, 100);

		for (int i = 0; i < 5; i++)
		{
			uint16_t val = adcBuffer[i];

			if (val < irMin[i])
				irMin[i] = val;

			if (val > irMax[i])
				irMax[i] = val;
		}
		HAL_Delay(2);
	}

	Motor_Stop();  // ⭐ CRITICAL: Stop motors after calibration

	for (int i = 0; i < 5; i++)
	{
		irThreshold[i] = (irMin[i] + irMax[i]) / 2;
	}

	while (1) {
		Bval = HAL_GPIO_ReadPin(PUSH_BUTTON_GPIO_Port, PUSH_BUTTON_Pin);

		if (Bval == 0) {
			HAL_Delay(50);  // Debounce
			break;
		}
		HAL_Delay(10);  // Prevent busy wait
	}
}

void Read_Line_Sensors(void)
{
	onLine = 0;

	for (int i = 0; i < 5; i++)
	{
		uint16_t raw = adcBuffer[i];

		// 1. Calculate Standard Normalization [0 = Black, 1000 = White]
		if (raw <= irMin[i])
			sensorNorm[i] = 0;

		else if (raw >= irMax[i])
			sensorNorm[i] = 1000;

		else
			sensorNorm[i] = (uint16_t) (
			((raw - irMin[i]) * 1000UL) / (irMax[i] - irMin[i])
			);

		// 2. Calculate Standard Binary Decision
		sensorBinary[i] = (raw > irThreshold[i]) ? 1 : 0;

		// 3. APPLY INVERSION LOGIC
		// If we are currently in "Black Line on White Surface" mode,
		// we flip everything so the PID thinks it's still a white line.
		if (currentLineType == LINE_BLACK_ON_WHITE)
		{
			// Flip the binary bit (1 becomes 0, 0 becomes 1)
			sensorBinary[i] = !sensorBinary[i];
			// Flip the normalized value (e.g., 900 brightness becomes 100)
			sensorNorm[i] = 1000 - sensorNorm[i];
		}

		// 4. Update Global "On Line" status
		if (sensorBinary[i])
			onLine = 1;
	}
}

float Compute_Line_Error(void)
{
	int activeSensors = 0;
	float errorSum = 0;
	bit_sensor = 0;

	for (int i = 0; i < 5; i++)

	{

		if (sensorBinary[i])
		{
			errorSum += sensorWeight[i] * sensorNorm[i];
			bit_sensor |= (sensorBinary[i] << (4 - i));
			activeSensors++;
		}
	}

	if (activeSensors == 0)
	{
		return previousError;
	}

	return errorSum / activeSensors;
}

void Line_PID_Control(void)
{
	pid_P = lineError;
	pid_I += lineError;

	if (pid_I > 300)
		pid_I = 300;

	if (pid_I < -300)
		pid_I = -300;

	pid_D = lineError - previousError;

	pidOutput = (Kp * pid_P) + (Ki * pid_I) + (Kd * pid_D);
	previousError = lineError;

	int leftSpeed = baseSpeed + pidOutput;
	int rightSpeed = baseSpeed - pidOutput;

	if (leftSpeed > maxSpeed)
		leftSpeed = maxSpeed;

	if (leftSpeed < 0)
		leftSpeed = 0;

	if (rightSpeed > maxSpeed)
		rightSpeed = maxSpeed;

	if (rightSpeed < 0)
		rightSpeed = 0;

	Motor_Forward((uint8_t) leftSpeed, (uint8_t) rightSpeed);
}

void Print_Sensor_Binary(void)
{
	int16_t err_i = (int16_t) (lineError * 100);

	int len = snprintf(uartBuf, sizeof(uartBuf),
	"BIN:%d%d%d%d%d | on:%d | err:%d\r\n",
	sensorBinary[0],sensorBinary[1],sensorBinary[2],sensorBinary[3],sensorBinary[4],onLine,err_i
	);

	HAL_UART_Transmit(&huart2, (uint8_t*) uartBuf, len, HAL_MAX_DELAY);
}

void Handle_Object_Detection(void)
{
    colorRed   = Color_ReadRed();
    colorGreen = Color_ReadGreen();
    colorBlue  = Color_ReadBlue();

    printf("RAW -> R:%lu G:%lu B:%lu\r\n", colorRed, colorGreen, colorBlue);

    HAL_GPIO_WritePin(GPIOC, RED_Pin | GREEN_Pin | BLUE_Pin, GPIO_PIN_RESET);

    	if (colorGreen < colorRed && colorGreen < colorBlue)
        {
            HAL_GPIO_WritePin(GPIOC, GREEN_Pin, GPIO_PIN_SET);
            printf("Detected: GREEN\r\n");
        }
        else if (colorRed < colorGreen && colorRed < colorBlue)
        {
            HAL_GPIO_WritePin(GPIOC, RED_Pin, GPIO_PIN_SET);
            printf("Detected: RED\r\n");
        }
        else if (colorBlue < colorRed && colorBlue < colorGreen)
        {
            HAL_GPIO_WritePin(GPIOC, BLUE_Pin, GPIO_PIN_SET);
            printf("Detected: BLUE\r\n");
        }

    // Engagement
    HAL_GPIO_WritePin(Electromagnet_GPIO_Port, Electromagnet_Pin, GPIO_PIN_SET);
    HAL_Delay(500);
    hasPackage = 1;
    blackZoneCounter = 0; // Reset for the return trip

    Motor_180_Turn();

    robotState = STATE_PID;
}

void Handle_Drop_Point(void)
{
	printf("Dropping package...\r\n");

	HAL_GPIO_WritePin(Electromagnet_GPIO_Port, Electromagnet_Pin,
			GPIO_PIN_RESET);

	HAL_Delay(1000);

	printf("Package dropped!\r\n");

	hasPackage = 0;
	robotState = STATE_PID;
	pid_I = 0;
	previousError = 0;
}

/* USER CODE END 4 */

/**
 * @brief  This function is executed in case of error occurrence.
 * @retval None
 */

void Error_Handler(void)
{
	/* USER CODE BEGIN Error_Handler_Debug */
	/* User can add his own implementation to report the HAL error return state */
	__disable_irq();

	while (1)
	{

	}
	/* USER CODE END Error_Handler_Debug */
}

#ifdef USE_FULL_ASSERT
/**
  * @brief  Reports the name of the source file and the source line number
  *         where the assert_param error has occurred.
  * @param  file: pointer to the source file name
  * @param  line: assert_param error line source number
  * @retval None
  */

void assert_failed(uint8_t *file, uint32_t line)
{
  /* USER CODE BEGIN 6 */
  /* User can add his own implementation to report the file name and line number,
     ex: printf("Wrong parameters value: file %s on line %d\r\n", file, line) */
  /* USER CODE END 6 */
}
#endif /* USE_FULL_ASSERT */
